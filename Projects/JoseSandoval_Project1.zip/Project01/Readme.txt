How to run:

My project is an IntelliJ IDEA project so it can be opened using that IDE or be run by using the included .JAR file.
Because it is a JavaFX application, the project has to be in a package so it cannot be compiled via terminal.

JDK used: 8.0.161