The program can be executed either by launching the .jar file from the CMD or a terminal
or by comping the source code files since there is not a java package this option
is possible. User prompts will guide you through the execution of the program.
Important! The input file should be located at the root of the C:\ drive.